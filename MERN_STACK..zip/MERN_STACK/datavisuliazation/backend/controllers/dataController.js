// controllers/dataController.js

const Data = require('../models/Data');

// Controller functions for CRUD operations

// Create a new data entry
const createData = async (req, res) => {
  try {
    const newData = new Data(req.body);
    await newData.save();
    res.status(201).json({ success: true, data: newData });
  } catch (error) {
    console.error('Error creating data:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// Get all data entries
const getAllData = async (req, res) => {
  try {
    const data = await Data.find();
    res.status(200).json({ success: true, data });
  } catch (error) {
    console.error('Error getting data:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// Get data by ID
const getDataById = async (req, res) => {
  try {
    const data = await Data.findById(req.params.id);
    if (!data) {
      return res.status(404).json({ success: false, message: 'Data not found' });
    }
    res.status(200).json({ success: true, data });
  } catch (error) {
    console.error('Error getting data by ID:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// Update data by ID
const updateDataById = async (req, res) => {
  try {
    const data = await Data.findByIdAndUpdate(req.params.id, req.body, {
      new: true,
      runValidators: true,
    });
    if (!data) {
      return res.status(404).json({ success: false, message: 'Data not found' });
    }
    res.status(200).json({ success: true, data });
  } catch (error) {
    console.error('Error updating data by ID:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

// Delete data by ID
const deleteDataById = async (req, res) => {
  try {
    const data = await Data.findByIdAndDelete(req.params.id);
    if (!data) {
      return res.status(404).json({ success: false, message: 'Data not found' });
    }
    res.status(200).json({ success: true, message: 'Data deleted successfully' });
  } catch (error) {
    console.error('Error deleting data by ID:', error);
    res.status(500).json({ success: false, message: 'Server Error' });
  }
};

module.exports = {
  createData,
  getAllData,
  getDataById,
  updateDataById,
  deleteDataById,
};
