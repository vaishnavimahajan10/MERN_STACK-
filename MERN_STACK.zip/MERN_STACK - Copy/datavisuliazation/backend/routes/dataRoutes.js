// routes/dataRoutes.js

const express = require('express');
const router = express.Router();
const dataController = require('../controllers/dataController');

// Create a new data entry
router.post('/', dataController.createData);

// Get all data entries
router.get('/', dataController.getAllData);

// Get data by ID
router.get('/:id', dataController.getDataById);

// Update data by ID
router.put('/:id', dataController.updateDataById);

// Delete data by ID
router.delete('/:id', dataController.deleteDataById);

module.exports = router;
